using System;

namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            HelloWorld helloObj = new HelloWorld();

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
