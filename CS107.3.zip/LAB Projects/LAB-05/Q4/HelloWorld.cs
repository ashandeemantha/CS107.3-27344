using System;

namespace ConsoleApplication
{
    class HelloWorld
    {
        private void SayHello()
        {
            Console.WriteLine("Hello, World!");
        }
    }
}
